#!/usr/bin/env python3
# process_ns_pipeline.py
# 处理 massdns 生成的 NS 结果，输出统计文件

import argparse
from collections import Counter
from publicsuffix2 import get_sld


def process_ns_file(ns_file, output_targets, output_target_counts, output_sld_counts, output_summary):
    print(f"解析 {ns_file} ...")
    target_counter = Counter()
    total_domains = 0

    # 逐行读取 NS 记录
    with open(ns_file, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 3 and parts[1] == "NS":
                domain = parts[0].rstrip(".")
                ns_host = parts[2].rstrip(".")
                target_counter[ns_host] += 1
                total_domains += 1

    # 统计 SLD
    sld_counter = Counter()
    for ns_host, count in target_counter.items():
        try:
            sld = get_sld(ns_host) or ns_host
            sld_counter[sld] += count
        except Exception:
            sld_counter[ns_host] += count

    # 输出目标 NS 主机列表（去重）
    with open(output_targets, "w", encoding="utf-8") as f:
        for host in sorted(target_counter.keys()):
            f.write(f"{host}\n")

    # 输出 NS 主机计数
    with open(output_target_counts, "w", encoding="utf-8") as f:
        for host, count in target_counter.most_common():
            f.write(f"{count}\t{host}\n")

    # 输出 SLD 计数
    with open(output_sld_counts, "w", encoding="utf-8") as f:
        for sld, count in sld_counter.most_common():
            f.write(f"{count}\t{sld}\n")

    # 输出汇总信息
    with open(output_summary, "w", encoding="utf-8") as f:
        f.write("=== NS 记录统计汇总 ===\n")
        f.write(f"总解析域名数: {total_domains}\n")
        f.write(f"不同 NS 主机数: {len(target_counter)}\n")
        f.write(f"不同 NS SLD 数: {len(sld_counter)}\n\n")

        f.write("=== Top 20 NS 主机 ===\n")
        for host, count in target_counter.most_common(20):
            f.write(f"{count}\t{host}\n")

        f.write("\n=== Top 20 NS SLD ===\n")
        for sld, count in sld_counter.most_common(20):
            f.write(f"{count}\t{sld}\n")

    print(f"[✓] 输出完成：\n  {output_targets}\n  {output_target_counts}\n  {output_sld_counts}\n  {output_summary}")


def main():
    parser = argparse.ArgumentParser(description="NS 记录处理管道")
    parser.add_argument("--ns_file", required=True, help="输入 NS 记录文件 (massdns 结果)")
    parser.add_argument("--output_targets", required=True, help="目标 NS 主机列表文件")
    parser.add_argument("--output_target_counts", required=True, help="目标 NS 主机计数文件")
    parser.add_argument("--output_sld_counts", required=True, help="NS 主机 SLD 计数文件")
    parser.add_argument("--output_summary", required=True, help="统计汇总文件")
    args = parser.parse_args()

    process_ns_file(
        args.ns_file,
        args.output_targets,
        args.output_target_counts,
        args.output_sld_counts,
        args.output_summary,
    )


if __name__ == "__main__":
    main()
