#!/usr/bin/env python3
# combined_analysis.py
# 合并的域名依赖分析工具，包含单一厂商依赖、跨层分离、多国依赖和集中度分析

import json
import argparse
from collections import Counter
import os

def analyze_single_vendor(data, output_dir):
    """分析单一厂商依赖率"""
    total = 0
    strong_single = 0
    weak_single = 0
    strong_counter = Counter()
    weak_counter = Counter()

    for domain, info in data.items():
        ns = info.get("ns_provider", "Unknown")
        cname = info.get("cname_provider", "Unknown")
        ip_asns = info.get("ip_asns", [])

        if not ip_asns:
            continue  # 没有 IP 的直接跳过
        ip_provider = ip_asns[0]  # 简化：取第一个 ASN org

        if ns == "Unknown" or ip_provider == "Unknown":
            continue

        total += 1

        # 三层强一致
        if cname != "Unknown" and ns == cname == ip_provider:
            strong_single += 1
            strong_counter[ns] += 1
        # 两层弱一致（忽略 cname）
        elif ns == ip_provider:
            weak_single += 1
            weak_counter[ns] += 1

    # 写结果到文件
    output_file = os.path.join(output_dir, "single_vendor_stats.txt")
    with open(output_file, "w", encoding="utf-8") as fout:
        fout.write("=== 单一厂商依赖分析 ===\n")
        fout.write(f"总域名数: {total}\n")
        fout.write(f"强单一依赖 (NS=CNAME=IP): {strong_single} ({strong_single/total:.2%})\n")
        fout.write(f"弱单一依赖 (NS=IP): {weak_single} ({weak_single/total:.2%})\n\n")

        fout.write("--- 强单一依赖分布 ---\n")
        for provider, cnt in strong_counter.most_common():
            fout.write(f"{provider}: {cnt} ({cnt/total:.2%})\n")

        fout.write("\n--- 弱单一依赖分布 ---\n")
        for provider, cnt in weak_counter.most_common():
            fout.write(f"{provider}: {cnt} ({cnt/total:.2%})\n")

    print(f"[✓] 单一厂商依赖分析完成，结果已写入 {output_file}")

def analyze_cross_layer(data, output_dir):
    """计算跨层分离率（忽略 Unknown 的 CNAME）"""
    total = 0
    cross_layer = 0
    combo_counter = Counter()

    for domain, info in data.items():
        ns = info.get("ns_provider", "Unknown")
        cname = info.get("cname_provider", "Unknown")
        ip_asns = info.get("ip_asns", [])

        if not ip_asns:
            continue
        ip_provider = ip_asns[0]

        # 如果 NS 和 IP 都是 Unknown，就跳过
        if ns == "Unknown" and ip_provider == "Unknown":
            continue

        total += 1

        # 如果 CNAME=Unknown，就只比较 NS 和 IP
        if cname == "Unknown":
            providers = set([p for p in [ns, ip_provider] if p != "Unknown"])
            combo = f"{ns}->{ip_provider}"
        else:
            providers = set([p for p in [ns, cname, ip_provider] if p != "Unknown"])
            combo = f"{ns}->{cname}->{ip_provider}"

        if len(providers) >= 2:  # 至少有两个不同厂商
            cross_layer += 1
            combo_counter[combo] += 1

    output_file = os.path.join(output_dir, "cross_layer_stats.txt")
    with open(output_file, "w", encoding="utf-8") as fout:
        fout.write("=== 跨层分离分析 ===\n")
        fout.write(f"总域名数: {total}\n")
        fout.write(f"跨层分离数: {cross_layer} ({cross_layer/total:.2%})\n\n")

        fout.write("--- Top 20 跨层组合 ---\n")
        for combo, cnt in combo_counter.most_common(20):
            fout.write(f"{combo}: {cnt} ({cnt/total:.2%})\n")

    print(f"[✓] 跨层分离分析完成，结果已写入 {output_file}")

def analyze_multicountry(data, output_dir):
    """计算多国物理依赖率：域名解析到多个国家的比例"""
    total = 0
    multicountry = 0
    country_count_dist = Counter()
    example_domains = []

    for domain, info in data.items():
        countries = [c for c in info.get("ip_countries", []) if c and c != "Unknown"]

        if not countries:
            continue

        total += 1
        unique_ctys = set(countries)
        country_count_dist[len(unique_ctys)] += 1

        if len(unique_ctys) > 1:
            multicountry += 1
            if len(example_domains) < 20:  # 保存部分样例
                example_domains.append((domain, list(unique_ctys)))

    # 输出到文件
    output_file = os.path.join(output_dir, "multicountry_stats.txt")
    with open(output_file, "w", encoding="utf-8") as fout:
        fout.write("=== 多国物理依赖分析 ===\n")
        fout.write(f"总域名数: {total}\n")
        fout.write(f"多国依赖数: {multicountry} ({multicountry/total:.2%})\n\n")

        fout.write("--- 国家数量分布 ---\n")
        for k, v in sorted(country_count_dist.items()):
            fout.write(f"{k} 个国家: {v} ({v/total:.2%})\n")

        fout.write("\n--- 示例域名 (最多20个) ---\n")
        for d, ctys in example_domains:
            fout.write(f"{d}: {','.join(ctys)}\n")

    print(f"[✓] 多国物理依赖分析完成，结果已写入 {output_file}")

def analyze_concentration(data, output_dir):
    """分析各层级的集中度"""
    def calc_concentration(counter):
        total = sum(counter.values())
        if total == 0:
            return 0, 0
        # Top3覆盖率
        top3 = sum([count for _, count in counter.most_common(3)]) / total
        # HHI
        hhi = sum((count/total)**2 for count in counter.values())
        return top3, hhi

    def get_layer_counter(layer_key):
        counter = Counter()
        for domain, info in data.items():
            if layer_key == "ip_asns":
                for asn in info.get(layer_key, []):
                    counter[asn] += 1
            else:
                val = info.get(layer_key, "Unknown")
                if val != "Unknown":
                    counter[val] += 1
        return counter

    layers = ["ns_provider", "cname_provider", "ip_asns"]

    # 用于保存输出的字典
    output = {}

    for layer in layers:
        counter = get_layer_counter(layer)
        top3, hhi = calc_concentration(counter)
        output[layer] = {
            "top3_coverage": round(top3*100, 2),
            "HHI": round(hhi, 4),
            "top3_providers": [p for p,_ in counter.most_common(3)]
        }

    # 写入文件
    output_file = os.path.join(output_dir, "concentration_summary.json")
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print(f"[✓] 集中度分析完成，结果已写入 {output_file}")

def main():
    parser = argparse.ArgumentParser(description="域名依赖分析工具")
    parser.add_argument("-d", "--dir", default="out_cn", 
                       help="输入输出目录路径，包含 domain_dependency.json 文件，结果也将输出到此目录")
    
    args = parser.parse_args()
    
    # 构建输入文件路径
    input_file = os.path.join(args.dir, "domain_dependency.json")
    
    # 确保目录存在
    os.makedirs(args.dir, exist_ok=True)
    
    # 读取数据
    print(f"[*] 正在读取数据从 {input_file}")
    try:
        with open(input_file, encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"[错误] 找不到输入文件: {input_file}")
        return
    except json.JSONDecodeError:
        print(f"[错误] 无法解析JSON文件: {input_file}")
        return
    
    print(f"[*] 成功加载 {len(data)} 个域名的数据")
    
    # 运行所有分析
    analyze_single_vendor(data, args.dir)
    analyze_cross_layer(data, args.dir)
    analyze_multicountry(data, args.dir)
    analyze_concentration(data, args.dir)
    
    print("[✓] 所有分析完成！")

if __name__ == "__main__":
    main()