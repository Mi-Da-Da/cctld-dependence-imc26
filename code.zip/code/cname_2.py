#!/usr/bin/env python3
# cname_pattern_extractor.py
# 从 zdns.json 和 target_counts.txt 生成 cname_pattern_candidates.json

import json
import argparse
import re
from collections import defaultdict, Counter
import geoip2.database
from publicsuffix2 import get_sld


def main():
    parser = argparse.ArgumentParser(description="从 zdns.json 和 target_counts.txt 提取 CNAME 模式候选")
    parser.add_argument("--zdns", required=True, help="输入 zdns.json 文件")
    parser.add_argument("--target_counts", required=True, help="输入 target_counts.txt 文件")
    parser.add_argument("--asn_db", required=True, help="GeoLite2-ASN.mmdb 文件路径")
    parser.add_argument("--country_db", required=True, help="GeoLite2-Country.mmdb 文件路径")
    parser.add_argument("--out", default="cname_pattern_candidates.json",
                        help="输出文件 (默认: cname_pattern_candidates.json)")
    parser.add_argument("--min_occ", type=int, default=10, help="候选最小出现次数 (默认=10)")
    parser.add_argument("--min_pct", type=float, default=0.75, help="候选最小占比 (默认=0.75)")
    args = parser.parse_args()

    # Step 0: 读取 target_counts.txt
    print("读取 target_counts.txt...")
    target_counts = {}
    with open(args.target_counts, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(None, 1)
            if len(parts) == 2:
                count = int(parts[0])
                target = parts[1]
                target_counts[target] = count

    # Step 1: 解析 ZDNS JSON 文件
    print("解析 ZDNS JSON 文件...")
    target2ips = defaultdict(list)

    with open(args.zdns, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue

            name = obj.get("name")
            results = obj.get("results", {})
            alookup = results.get("ALOOKUP", {})

            data = alookup.get("data")
            if data is None:
                continue

            ips = data.get("ipv4_addresses", []) + data.get("ipv6_addresses", [])

            if name and ips:
                target2ips[name].extend(ips)

    # 去重 IP 地址
    for target in target2ips:
        target2ips[target] = list(set(target2ips[target]))

    # Step 2: GeoIP 查询
    print("执行 GeoIP 查询...")
    all_ips = set()
    for ips in target2ips.values():
        all_ips.update(ips)

    reader_asn = geoip2.database.Reader(args.asn_db)
    reader_cty = geoip2.database.Reader(args.country_db)

    ip2info = {}
    for ip in all_ips:
        info = {"country": "Unknown", "asn": None, "asn_org": "Unknown"}
        try:
            a = reader_asn.asn(ip)
            info["asn"] = a.autonomous_system_number
            info["asn_org"] = a.autonomous_system_organization
        except Exception:
            pass

        try:
            c = reader_cty.country(ip)
            iso = getattr(c.country, "iso_code", None)
            info["country"] = iso if iso else (getattr(c.country, "name", "Unknown"))
        except Exception:
            pass

        ip2info[ip] = info

    reader_asn.close()
    reader_cty.close()

    # Step 3: 构建 target -> ASN / 国家映射
    print("构建目标到 ASN/国家 的映射...")
    t2asns = defaultdict(set)
    t2ctys = defaultdict(set)

    for target, count in target_counts.items():
        ips = target2ips.get(target, [])
        if not ips:  # 没解析到 IP，打上 unknown
            t2asns[target].add(("unknown", "unknown"))
            t2ctys[target].add("Unknown")
        else:
            for ip in ips:
                info = ip2info.get(ip, {})
                asn = info.get("asn")
                if asn:
                    t2asns[target].add((asn, info.get("asn_org", "")))
                t2ctys[target].add(info.get("country", "Unknown"))

    # Step 4: 按 SLD 聚合
    print("按 SLD 聚合数据...")
    sld_data = defaultdict(lambda: {
        "total": 0,
        "asn_counter": Counter(),
        "country_counter": Counter(),
        "targets": set()
    })

    for target, count in target_counts.items():
        sld = get_sld(target) or target
        sld_entry = sld_data[sld]
        sld_entry["total"] += count
        sld_entry["targets"].add(target)

        # ASN 信息
        asns = t2asns.get(target, set())
        if asns:
            weight = count / len(asns)
            for asn in asns:
                sld_entry["asn_counter"][asn] += weight
        else:
            sld_entry["asn_counter"][("unknown", "unknown")] += count

        # 国家信息
        countries = t2ctys.get(target, set())
        if countries:
            weight = count / len(countries)
            for country in countries:
                sld_entry["country_counter"][country] += weight
        else:
            sld_entry["country_counter"]["Unknown"] += count

    # Step 5: 生成候选模式
    print("生成候选模式...")
    candidates = []

    for sld, info in sorted(sld_data.items(), key=lambda x: -x[1]["total"]):
        total = info["total"]
        if total < args.min_occ:
            continue

        top_asn, top_asn_count = info["asn_counter"].most_common(1)[0]
        pct = top_asn_count / total if total > 0 else 0

        if pct < args.min_pct:
            continue

        # 正则模式
        sld_esc = re.escape(sld)
        pattern1 = rf"(?:^|\.){sld_esc}(?:\.|$)"

        label = sld.split(".")[0]
        pattern2 = None
        if len(label) <= 12 and label.isalnum():
            pattern2 = rf"(?:^|\.){re.escape(label)}[a-z0-9-]*?(?:\.|$)"

        entry = {
            "sld": sld,
            "total_count": total,
            "provider_hint": top_asn[1],
            "top_asn": {"asn": top_asn[0], "org": top_asn[1]},
            "pct": round(pct, 3),
            "countries": list(info["country_counter"].keys())[:5],
            "example_targets": list(info["targets"])[:10],
            "suggested_patterns": [pattern1] + ([pattern2] if pattern2 else [])
        }
        candidates.append(entry)

    # 输出
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(candidates, f, ensure_ascii=False, indent=2)

    print(f"完成! 生成 {len(candidates)} 个候选模式到 {args.out}")


if __name__ == "__main__":
    main()
