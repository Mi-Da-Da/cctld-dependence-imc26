#!/bin/bash
# run_full_pipeline.sh
# 一键运行：
#   Step 1: 解析CNAME -> 分类 -> 提取未知 -> 统计
#   Step 2: zdns解析 targets.txt -> 生成 cname_pattern_candidates.json
# 使用方式：
#   ./run_full_pipeline.sh <国家后缀文件>
# 例如：
#   ./run_full_pipeline.sh country_list.txt

set -e  # 出错立即退出
set -x  # 输出命令以便调试

# ========= 参数检查 =========
if [ $# -lt 1 ]; then
    echo "用法: $0 <国家后缀文件>"
    echo "例如: $0 country_list.txt"
    echo "country_list.txt 格式：每行一个后缀，如:"
    echo "cn"
    echo "fr" 
    echo "us"
    exit 1
fi

COUNTRY_FILE="$1"

# ========= 检查国家后缀文件是否存在 =========
if [ ! -f "$COUNTRY_FILE" ]; then
    echo "错误: 国家后缀文件 $COUNTRY_FILE 不存在"
    exit 1
fi

# ========= 读取国家后缀并逐个处理 =========
while IFS= read -r PREFIX || [ -n "$PREFIX" ]; do
    # 跳过空行和注释行
    PREFIX=$(echo "$PREFIX" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    if [ -z "$PREFIX" ] || [[ "$PREFIX" =~ ^# ]]; then
        continue
    fi
    
    echo ""
    echo "========================================"
    echo "[*] 开始处理国家后缀: $PREFIX"
    echo "========================================"
    
    DOMAIN_FILE="${PREFIX}_domains.txt"
    RESOLVER_FILE="resolvers_2.txt"
    PATTERN_FILE="cname_pattern.json"

    # ========= 检查域名文件是否存在 =========
    if [ ! -f "$DOMAIN_FILE" ]; then
        echo "[!] 警告: 域名文件 $DOMAIN_FILE 不存在，跳过"
        continue
    fi

    # ========= 输出路径准备 =========
    OUTPUT_DIR="$PREFIX"
    mkdir -p "$OUTPUT_DIR"

    # ========= Step 1: CNAME 解析与分类 =========

    CNAME_RESULT="$OUTPUT_DIR/${PREFIX}_cname_results.txt"
    OUTPUT_CLASSIFIED="$OUTPUT_DIR/${PREFIX}_cname_with_provider.txt"
    OUTPUT_UNKNOWN="$OUTPUT_DIR/${PREFIX}_unknown_cname.txt"
    OUTPUT_TARGETS="$OUTPUT_DIR/${PREFIX}_targets.txt"
    OUTPUT_TARGET_COUNTS="$OUTPUT_DIR/${PREFIX}_target_counts.txt"
    OUTPUT_SLD_COUNTS="$OUTPUT_DIR/${PREFIX}_sld_counts.txt"

    echo "[*] 输入文件: $DOMAIN_FILE"
    echo "[*] 输出文件夹: $OUTPUT_DIR"

    # Step 1.1: 使用 zdns 解析 A（zdns 在 A 查询时会返回完整解析链，包括 CNAME -> A）
    echo "[*] 运行 zdns A..."
    if [ ! -f "./zdns" ]; then
        echo "[!] 错误: zdns 可执行文件不存在"
        exit 1
    fi

    RAW_ZDNS="$OUTPUT_DIR/${PREFIX}_zdns_raw.json"
    A_RESULT="$OUTPUT_DIR/${PREFIX}_a_results.txt"
    CNAME_RESULT="$OUTPUT_DIR/${PREFIX}_cname_results.txt"
    MULTI_CNAME_RESULT="$OUTPUT_DIR/${PREFIX}_multi_cname_results.txt"

    # 用 zdns A 进行查询，保存原始 json 到文件
    cat "$DOMAIN_FILE" | ./zdns A --threads=300 --timeout=12 --retries=2 --result-verbosity=short --name-servers=@"$RESOLVER_FILE" > "$RAW_ZDNS"

    # 一阶 CNAME：原始域名指向的第一个 CNAME（保持原逻辑）
    jq -r '
      . as $root
      | (.results.A.data.answers // [])
      | map(select(.type=="CNAME"))
      | .[0]? as $first
      | if $first then "\($root.name) \($first.type) \($first.answer)" else empty end
    ' "$RAW_ZDNS" > "$CNAME_RESULT"

    # 二阶及以上：从 answers 中取索引 1 及之后的 CNAME 记录，直接输出该记录的 name -> answer（即中间名 -> 下一级）
    # 然后按中间名去重（若多个原始域都产生相同中间名，仅保留一次）
    jq -r '
      . as $root
      | (.results.A.data.answers // [])
      | map(select(.type=="CNAME"))
      | .[1:][]?
      | "\(.name) \(.type) \(.answer)"
    ' "$RAW_ZDNS" | awk '!seen[$1]++' > "$MULTI_CNAME_RESULT"

    # A 记录输出：格式为 "name A ip"
    jq -r '
      . as $root
      | (.results.A.data.answers // [])
      | .[]?
      | select(.type=="A")
      | "\(.name) \(.type) \(.answer)"
    ' "$RAW_ZDNS" > "$A_RESULT"




    # Step 1.2: 运行 Python 分类统计脚本
    echo "[*] 运行 CNAME 分类与统计..."
    python3 cname_1.py \
        --cname_file "$CNAME_RESULT" \
        --pattern_file "$PATTERN_FILE" \
        --output_classified "$OUTPUT_CLASSIFIED" \
        --output_unknown "$OUTPUT_UNKNOWN" \
        --output_targets "$OUTPUT_TARGETS" \
        --output_target_counts "$OUTPUT_TARGET_COUNTS" \
        --output_sld_counts "$OUTPUT_SLD_COUNTS"

    echo "[✓] 第一阶段完成! 生成文件："
    echo "  - $OUTPUT_CLASSIFIED"
    echo "  - $OUTPUT_UNKNOWN"
    echo "  - $OUTPUT_TARGETS"
    echo "  - $OUTPUT_TARGET_COUNTS"
    echo "  - $OUTPUT_SLD_COUNTS"

    # ========= Step 2: 目标域名二次解析 & 模式提取 =========

    WORKDIR="./$PREFIX"
    TARGETS_FILE="$WORKDIR/${PREFIX}_targets.txt"
    ZDNS_RESULT="$WORKDIR/${PREFIX}_zdns.json"
    CANDIDATES_OUT="$WORKDIR/${PREFIX}_cname_pattern_candidates.json"

    # GeoIP 数据库（全局路径）
    ASN_DB="GeoLite2-ASN.mmdb"
    COUNTRY_DB="GeoLite2-Country.mmdb"

    # Step 2.1: 使用 zdns 再解析
    echo "[*] 使用 zdns 解析 $TARGETS_FILE -> $ZDNS_RESULT ..."
    ./zdns alookup --threads=200 --name-servers=@"$RESOLVER_FILE" --timeout=6 < "$TARGETS_FILE" > "$ZDNS_RESULT"

    # Step 2.2: 调用 Python 提取候选模式
    echo "[*] 调用 cname_2.py 提取候选模式..."
    python3 cname_2.py \
        --zdns "$ZDNS_RESULT" \
        --target_counts "$WORKDIR/${PREFIX}_target_counts.txt" \
        --asn_db "$ASN_DB" \
        --country_db "$COUNTRY_DB" \
        --out "$CANDIDATES_OUT"

    echo "[✓] 国家后缀 $PREFIX 处理完成!"
    echo "生成文件："
    echo "  - $ZDNS_RESULT"
    echo "  - $CANDIDATES_OUT"

done < "$COUNTRY_FILE"

echo ""
echo "[✔] 所有国家后缀已处理完毕!"
echo "========================================"