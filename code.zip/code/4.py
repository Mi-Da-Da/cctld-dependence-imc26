import json
from collections import Counter

# 读取文件
with open("out_cn/domain_dependency.json", "r", encoding="utf-8") as f:
    data = json.load(f)

def calc_concentration(counter):
    total = sum(counter.values())
    if total == 0:
        return 0, 0
    # Top3覆盖率
    top3 = sum([count for _, count in counter.most_common(3)]) / total
    # HHI
    hhi = sum((count/total)**2 for count in counter.values())
    return top3, hhi

def get_layer_counter(layer_key):
    counter = Counter()
    for domain, info in data.items():
        if layer_key == "ip_asns":
            for asn in info.get(layer_key, []):
                counter[asn] += 1
        else:
            val = info.get(layer_key, "Unknown")
            if val != "Unknown":
                counter[val] += 1
    return counter

layers = ["ns_provider", "cname_provider", "ip_asns"]

# 用于保存输出的字典
output = {}

for layer in layers:
    counter = get_layer_counter(layer)
    top3, hhi = calc_concentration(counter)
    output[layer] = {
        "top3_coverage": round(top3*100, 2),
        "HHI": round(hhi, 4),
        "top3_providers": [p for p,_ in counter.most_common(3)]
    }

# 写入文件
with open("out_cn/concentration_summary.json", "w", encoding="utf-8") as f:
    json.dump(output, f, indent=2, ensure_ascii=False)

print("集中度分析结果已写入 out_cn/concentration_summary.json")
