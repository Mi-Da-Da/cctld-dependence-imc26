#!/usr/bin/env python3
# analyze_cross_layer.py
# 计算跨层分离率（忽略 Unknown 的 CNAME）

import json
from collections import Counter

INPUT_FILE = "out_cn/domain_dependency.json"
OUTPUT_FILE = "out_cn/cross_layer_stats.txt"

def main():
    with open(INPUT_FILE, encoding="utf-8") as f:
        data = json.load(f)

    total = 0
    cross_layer = 0
    combo_counter = Counter()

    for domain, info in data.items():
        ns = info.get("ns_provider", "Unknown")
        cname = info.get("cname_provider", "Unknown")
        ip_asns = info.get("ip_asns", [])

        if not ip_asns:
            continue
        ip_provider = ip_asns[0]

        # 如果 NS 和 IP 都是 Unknown，就跳过
        if ns == "Unknown" and ip_provider == "Unknown":
            continue

        total += 1

        # 如果 CNAME=Unknown，就只比较 NS 和 IP
        if cname == "Unknown":
            providers = set([p for p in [ns, ip_provider] if p != "Unknown"])
            combo = f"{ns}->{ip_provider}"
        else:
            providers = set([p for p in [ns, cname, ip_provider] if p != "Unknown"])
            combo = f"{ns}->{cname}->{ip_provider}"

        if len(providers) >= 2:  # 至少有两个不同厂商
            cross_layer += 1
            combo_counter[combo] += 1

    with open(OUTPUT_FILE, "w", encoding="utf-8") as fout:
        fout.write("=== 跨层分离分析 ===\n")
        fout.write(f"总域名数: {total}\n")
        fout.write(f"跨层分离数: {cross_layer} ({cross_layer/total:.2%})\n\n")

        fout.write("--- Top 20 跨层组合 ---\n")
        for combo, cnt in combo_counter.most_common(20):
            fout.write(f"{combo}: {cnt} ({cnt/total:.2%})\n")

    print(f"[✓] 分析完成，结果已写入 {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
