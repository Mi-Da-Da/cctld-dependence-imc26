#!/usr/bin/env python3
# analyze_single_vendor.py
# 从 domain_dependency.json 计算单一厂商依赖率，并输出到文件

import json
from collections import Counter

INPUT_FILE = "out_cn/domain_dependency.json"
OUTPUT_FILE = "out_cn/single_vendor_stats.txt"

def main():
    with open(INPUT_FILE, encoding="utf-8") as f:
        data = json.load(f)

    total = 0
    strong_single = 0
    weak_single = 0
    strong_counter = Counter()
    weak_counter = Counter()

    for domain, info in data.items():
        ns = info.get("ns_provider", "Unknown")
        cname = info.get("cname_provider", "Unknown")
        ip_asns = info.get("ip_asns", [])

        if not ip_asns:
            continue  # 没有 IP 的直接跳过
        ip_provider = ip_asns[0]  # 简化：取第一个 ASN org

        if ns == "Unknown" or ip_provider == "Unknown":
            continue

        total += 1

        # 三层强一致
        if cname != "Unknown" and ns == cname == ip_provider:
            strong_single += 1
            strong_counter[ns] += 1
        # 两层弱一致（忽略 cname）
        elif ns == ip_provider:
            weak_single += 1
            weak_counter[ns] += 1

    # 写结果到文件
    with open(OUTPUT_FILE, "w", encoding="utf-8") as fout:
        fout.write("=== 单一厂商依赖分析 ===\n")
        fout.write(f"总域名数: {total}\n")
        fout.write(f"强单一依赖 (NS=CNAME=IP): {strong_single} ({strong_single/total:.2%})\n")
        fout.write(f"弱单一依赖 (NS=IP): {weak_single} ({weak_single/total:.2%})\n\n")

        fout.write("--- 强单一依赖分布 ---\n")
        for provider, cnt in strong_counter.most_common():
            fout.write(f"{provider}: {cnt} ({cnt/total:.2%})\n")

        fout.write("\n--- 弱单一依赖分布 ---\n")
        for provider, cnt in weak_counter.most_common():
            fout.write(f"{provider}: {cnt} ({cnt/total:.2%})\n")

    print(f"[✓] 分析完成，结果已写入 {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
