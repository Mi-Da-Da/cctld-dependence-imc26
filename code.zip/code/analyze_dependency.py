#!/usr/bin/env python3
# analyze_dependency.py

import json
import argparse
import os
from collections import defaultdict, Counter
import geoip2.database
from tqdm import tqdm

def parse_ns_file(ns_file, ns_patterns):
    domain2ns = {}
    with open(ns_file, encoding="utf-8") as f:
        for line in tqdm(f, desc="Parsing NS file"):
            parts = line.strip().split()
            if len(parts) >= 3 and parts[1] == "NS":
                domain = parts[0].rstrip(".").lower()
                ns_host = parts[2].rstrip(".").lower()
                provider = match_provider(ns_host, ns_patterns)
                domain2ns[domain] = provider
    return domain2ns

def parse_cname_file(cname_file, cname_patterns):
    domain2cname = {}
    with open(cname_file, encoding="utf-8") as f:
        for line in tqdm(f, desc="Parsing CNAME file"):
            parts = line.strip().split()
            if len(parts) >= 3 and parts[1] == "CNAME":
                domain = parts[0].rstrip(".").lower()
                cname = parts[2].rstrip(".").lower()
                provider = match_provider(cname, cname_patterns)
                domain2cname[domain] = provider
    return domain2cname

def parse_a_file(a_file):
    domain2ips = defaultdict(set)
    with open(a_file, encoding="utf-8") as f:
        for line in tqdm(f, desc="Parsing A file"):
            parts = line.strip().split()
            if len(parts) >= 3 and parts[1] == "A":
                domain = parts[0].rstrip(".").lower()
                ip = parts[2]
                domain2ips[domain].add(ip)
    return domain2ips

def match_provider(host, patterns):
    for p in patterns:
        for pat in p.get("suggested_patterns", []):
            if host.endswith(p["sld"]):
                return p.get("provider_hint", "Unknown")
    return "Unknown"

def geoip_lookup(all_ips, asn_db, country_db):
    reader_asn = geoip2.database.Reader(asn_db)
    reader_cty = geoip2.database.Reader(country_db)
    ip2asn, ip2cty = {}, {}

    for ip in tqdm(all_ips, desc="GeoIP lookup"):
        asn, org, cty = "unknown", "unknown", "Unknown"
        try:
            a = reader_asn.asn(ip)
            asn = a.autonomous_system_number
            org = a.autonomous_system_organization
        except:
            pass
        try:
            c = reader_cty.country(ip)
            iso = getattr(c.country, "iso_code", None)
            cty = iso if iso else getattr(c.country, "name", "Unknown")
        except:
            pass
        ip2asn[ip] = (asn, org)
        ip2cty[ip] = cty

    reader_asn.close()
    reader_cty.close()
    return ip2asn, ip2cty

def integrate(ns_map, cname_map, a_map, ip2asn, ip2cty, out_file):
    out = {}
    for d in tqdm(set(list(ns_map.keys()) + list(cname_map.keys()) + list(a_map.keys())),
                  desc="Integrating results"):
        ns_provider = ns_map.get(d, "Unknown")
        cname_provider = cname_map.get(d, "Unknown")
        ips = a_map.get(d, [])
        asns, countries = set(), set()
        for ip in ips:
            if ip in ip2asn:
                asns.add(ip2asn[ip][1])  # org
            if ip in ip2cty:
                countries.add(ip2cty[ip])
        out[d] = {
            "ns_provider": ns_provider,
            "cname_provider": cname_provider,
            "ip_asns": list(asns),
            "ip_countries": list(countries)
        }
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"[✓] 输出结果到 {out_file}, 共 {len(out)} 个域名")

def process_country(tld):
    """处理单个国家的数据"""
    print(f"\n[*] 开始处理国家: {tld}")
    
    # 构建文件路径
    ns_file = f"{tld}_ns/{tld}_ns_results.txt"
    cname_file = f"{tld}/{tld}_cname_results.txt"
    a_file = f"{tld}/{tld}_a_results.txt"
    ns_patterns = f"{tld}_ns/{tld}_ns_pattern_candidates.json"  # 修改这里
    cname_patterns = f"{tld}/{tld}_cname_pattern_candidates.json"  # 修改这里
    asn_db = "GeoLite2-ASN.mmdb"
    country_db = "GeoLite2-Country.mmdb"
    out_dir = f"out_{tld}"
    
    # 确保输出目录存在
    os.makedirs(out_dir, exist_ok=True)
    
    # 检查必需文件是否存在
    required_files = [ns_file, cname_file, a_file, ns_patterns, cname_patterns, asn_db, country_db]
    missing_files = [f for f in required_files if not os.path.exists(f)]
    
    if missing_files:
        print(f"[!] 跳过 {tld}，缺少文件: {missing_files}")
        return
    
    print("[*] 加载模式文件...")
    ns_patterns_data = json.load(open(ns_patterns, encoding="utf-8"))
    cname_patterns_data = json.load(open(cname_patterns, encoding="utf-8"))

    print("[*] Parse NS file...")
    ns_map = parse_ns_file(ns_file, ns_patterns_data)

    print("[*] Parse CNAME file...")
    cname_map = parse_cname_file(cname_file, cname_patterns_data)

    print("[*] Parse A file...")
    a_map = parse_a_file(a_file)

    print("[*] GeoIP 查询...")
    all_ips = set(ip for ips in a_map.values() for ip in ips)
    ip2asn, ip2cty = geoip_lookup(all_ips, asn_db, country_db)

    print("[*] 整合结果...")
    integrate(ns_map, cname_map, a_map, ip2asn, ip2cty, f"{out_dir}/domain_dependency.json")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--countries_file", default="countries.txt", help="国家列表文件")
    args = parser.parse_args()

    # 读取国家列表
    if not os.path.exists(args.countries_file):
        print(f"[!] 错误: 国家列表文件 {args.countries_file} 不存在")
        return
    
    with open(args.countries_file, 'r', encoding='utf-8') as f:
        countries = [line.strip() for line in f if line.strip() and not line.startswith('#')]
    
    print(f"[*] 找到 {len(countries)} 个国家: {', '.join(countries)}")
    
    # 处理每个国家
    for country in countries:
        process_country(country)
    
    print(f"\n[✔] 所有国家处理完成!")

if __name__ == "__main__":
    main()