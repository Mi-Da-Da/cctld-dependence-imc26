#!/usr/bin/env python3
# analyze_multicountry.py
# 计算多国物理依赖率：域名解析到多个国家的比例

import json
from collections import Counter

INPUT_FILE = "out_cn/domain_dependency.json"
OUTPUT_FILE = "out_cn/multicountry_stats.txt"

def main():
    with open(INPUT_FILE, encoding="utf-8") as f:
        data = json.load(f)

    total = 0
    multicountry = 0
    country_count_dist = Counter()
    example_domains = []

    for domain, info in data.items():
        countries = [c for c in info.get("ip_countries", []) if c and c != "Unknown"]

        if not countries:
            continue

        total += 1
        unique_ctys = set(countries)
        country_count_dist[len(unique_ctys)] += 1

        if len(unique_ctys) > 1:
            multicountry += 1
            if len(example_domains) < 20:  # 保存部分样例
                example_domains.append((domain, list(unique_ctys)))

    # 输出到文件
    with open(OUTPUT_FILE, "w", encoding="utf-8") as fout:
        fout.write("=== 多国物理依赖分析 ===\n")
        fout.write(f"总域名数: {total}\n")
        fout.write(f"多国依赖数: {multicountry} ({multicountry/total:.2%})\n\n")

        fout.write("--- 国家数量分布 ---\n")
        for k, v in sorted(country_count_dist.items()):
            fout.write(f"{k} 个国家: {v} ({v/total:.2%})\n")

        fout.write("\n--- 示例域名 (最多20个) ---\n")
        for d, ctys in example_domains:
            fout.write(f"{d}: {','.join(ctys)}\n")

    print(f"[✓] 分析完成，结果已写入 {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
