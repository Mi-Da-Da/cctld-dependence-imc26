#!/bin/bash
# run_analysis_pipeline.sh

set -e  # 出错立即退出

# ========= 检查国家文件是否存在 =========
COUNTRIES_FILE="countries.txt"
if [ ! -f "$COUNTRIES_FILE" ]; then
    echo "[!] 错误: $COUNTRIES_FILE 不存在"
    exit 1
fi

# ========= 读取国家列表 =========
COUNTRIES=()
while IFS= read -r line || [ -n "$line" ]; do
    # 跳过空行和注释行
    line=$(echo "$line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    if [ -n "$line" ] && [[ ! "$line" =~ ^# ]]; then
        COUNTRIES+=("$line")
    fi
done < "$COUNTRIES_FILE"

echo "========================================"
echo "开始执行分析流水线"
echo "找到 ${#COUNTRIES[@]} 个国家: ${COUNTRIES[*]}"
echo "========================================"

# ========= 步骤1: 运行 analyze_dependency.py =========
echo "[*] 步骤1: 运行 analyze_dependency.py..."
python3 analyze_dependency.py --countries_file countries.txt
if [ $? -eq 0 ]; then
    echo "[✓] analyze_dependency.py 执行成功"
else
    echo "[!] analyze_dependency.py 执行失败"
    exit 1
fi

# ========= 步骤2: 对每个国家运行 data.py =========
echo ""
echo "[*] 步骤2: 对每个国家运行 data.py..."
for COUNTRY in "${COUNTRIES[@]}"; do
    echo ""
    echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    echo "处理国家: $COUNTRY"
    echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    
    # 检查输出目录是否存在
    OUTPUT_DIR="out_${COUNTRY}"
    if [ ! -d "$OUTPUT_DIR" ]; then
        echo "[!] 警告: 输出目录 $OUTPUT_DIR 不存在，跳过"
        continue
    fi
    
    # 检查 domain_dependency.json 是否存在
    DEPENDENCY_FILE="${OUTPUT_DIR}/domain_dependency.json"
    if [ ! -f "$DEPENDENCY_FILE" ]; then
        echo "[!] 警告: 依赖文件 $DEPENDENCY_FILE 不存在，跳过"
        continue
    fi
    
    echo "[$COUNTRY] 运行 data.py..."
    python3 data.py --dir "$OUTPUT_DIR"
    
    if [ $? -eq 0 ]; then
        echo "[✓] data.py 执行成功"
    else
        echo "[!] data.py 执行失败"
        exit 1
    fi
    
    echo "[✓] 国家 $COUNTRY 处理完成"
done

echo ""
echo "========================================"
echo "所有国家分析流水线执行完成！"
echo "========================================"