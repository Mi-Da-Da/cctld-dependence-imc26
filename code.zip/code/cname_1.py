#!/usr/bin/env python3
# process_cname_pipeline.py
# 整合脚本：处理CNAME -> 全部标记为 Unknown -> 提取 -> 统计

import json
import re
import argparse
from collections import Counter, defaultdict
from publicsuffix2 import get_sld

def classify_cname(cname_file, pattern_file, output_file):
    """分类CNAME记录（此版本强制全部归为 Unknown）"""
    print("⚠️ 跳过模式匹配，全部CNAME视为 Unknown")

    results = defaultdict(list)

    with open(cname_file, "r", encoding="utf-8") as fin:
        for line in fin:
            parts = line.strip().split()
            if len(parts) >= 3 and parts[1] == "CNAME":
                domain = parts[0].rstrip(".")
                cname = parts[2].rstrip(".")
                provider = "Unknown"   # ⬅️ 强制为 Unknown
                results[provider].append((domain, cname))

    print("输出分类结果...")
    with open(output_file, "w", encoding="utf-8") as fout:
        fout.write(f"\n=== Unknown ({len(results['Unknown'])} domains) ===\n")
        for domain, cname in results["Unknown"]:
            fout.write(f"{domain}  CNAME  {cname}\n")
    
    return results

def extract_unknown(classified_file, output_file):
    """从分类结果中提取 Unknown 部分"""
    print("提取 Unknown 域名...")
    in_unknown = False
    unknown_lines = []
    
    with open(classified_file, "r", encoding="utf-8") as f:
        for line in f:
            if line.startswith("=== Unknown"):
                in_unknown = True
                unknown_lines.append(line)
                continue
            elif line.startswith("===") and in_unknown:
                break
            if in_unknown:
                unknown_lines.append(line)
    
    with open(output_file, "w", encoding="utf-8") as f:
        f.writelines(unknown_lines)
    
    print(f"Unknown 域名已提取到 {output_file}")

def process_unknown_cname(input_file, output_targets, output_target_counts, output_sld_counts):
    """处理 unknown_cname.txt，提取目标并生成统计"""
    print("解析 unknown_cname.txt 文件...")
    target_counter = Counter()
    
    with open(input_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("==="):
                continue
            
            parts = line.split()
            if len(parts) >= 3 and parts[1] == "CNAME":
                target = parts[2].rstrip(".")
                target_counter[target] += 1

    # 统计 SLD
    print("统计 SLD...")
    sld_counter = Counter()
    for target in target_counter:
        try:
            sld = get_sld(target) or target
            sld_counter[sld] += target_counter[target]
        except:
            sld_counter[target] += target_counter[target]

    # 输出文件
    print("输出目标文件...")
    with open(output_targets, "w", encoding="utf-8") as f:
        for target in sorted(target_counter.keys()):
            f.write(f"{target}\n")
    
    with open(output_target_counts, "w", encoding="utf-8") as f:
        for target, count in target_counter.most_common():
            f.write(f"{count}\t{target}\n")
    
    with open(output_sld_counts, "w", encoding="utf-8") as f:
        for sld, count in sld_counter.most_common():
            f.write(f"{count}\t{sld}\n")

def main():
    parser = argparse.ArgumentParser(description="CNAME处理管道（全部 Unknown）")
    parser.add_argument("--cname_file", required=True, help="输入 CNAME 文件")
    parser.add_argument("--pattern_file", required=True, help="模式文件（保留参数但忽略）")
    parser.add_argument("--output_classified", default="cname_with_provider.txt")
    parser.add_argument("--output_unknown", default="unknown_cname.txt")
    parser.add_argument("--output_targets", default="targets.txt")
    parser.add_argument("--output_target_counts", default="target_counts.txt")
    parser.add_argument("--output_sld_counts", default="sld_counts.txt")
    args = parser.parse_args()

    # 步骤 1: 分类 CNAME（全部 Unknown）
    classify_cname(args.cname_file, args.pattern_file, args.output_classified)
    
    # 步骤 2: 提取 Unknown
    extract_unknown(args.output_classified, args.output_unknown)
    
    # 步骤 3: 统计 Unknown
    process_unknown_cname(
        args.output_unknown, 
        args.output_targets, 
        args.output_target_counts, 
        args.output_sld_counts
    )
    
    print("✅ 处理完成!")
    print(f"- 分类结果: {args.output_classified}")
    print(f"- 未知域名: {args.output_unknown}")
    print(f"- 目标域名列表: {args.output_targets}")
    print(f"- 目标计数: {args.output_target_counts}")
    print(f"- SLD计数: {args.output_sld_counts}")

if __name__ == "__main__":
    main()
